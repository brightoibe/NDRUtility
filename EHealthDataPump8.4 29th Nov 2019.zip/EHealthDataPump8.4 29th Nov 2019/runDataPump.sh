#!/bin/bash 
java -jar EHealthDataPump8.4.jar

